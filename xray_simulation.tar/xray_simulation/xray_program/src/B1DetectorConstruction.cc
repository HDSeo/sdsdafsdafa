
#include "B1DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"


B1DetectorConstruction::B1DetectorConstruction()
: G4VUserDetectorConstruction(),
  fScoringVolume(0)
{ }


B1DetectorConstruction::~B1DetectorConstruction()
{ }


G4VPhysicalVolume* B1DetectorConstruction::Construct()
{  
  G4NistManager* nist = G4NistManager::Instance();
  
  // Envelope parameters
  //
  G4double env_sizeXY = 20*cm, env_sizeZ = 100*cm;
  //G4Material* env_mat = nist->FindOrBuildMaterial("G4_WATER");
   
  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  G4Material* vacuum =
     new G4Material("Vacuum",1,1.008*g/mole, 1.e-25*g/cm3,kStateGas,2.73*kelvin,1.e-25*g/cm3);

  //     
  // World
  //
  G4double world_sizeXY = 1.4*env_sizeXY;
  G4double world_sizeZ  = 1.4*env_sizeZ;
  //G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  
  //G4Material* world_mat = nist->FindOrBuildMaterial("G4_Pb");
  G4Box* solidWorld =    
    new G4Box("World",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size
      
  G4LogicalVolume* logicWorld =                         
    new G4LogicalVolume(solidWorld,          //its solid
//                        world_mat,           //its material
			vacuum,
                        "World");            //its name
                                   
  G4VPhysicalVolume* physWorld = 
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking
                     
  //     
  // Envelope
  //  


  //G4Material* air = nist->FindOrBuildMaterial("G4_AIR");

  G4Box* solidEnv =    
    new G4Box("Envelope",                    //its name
        0.5*env_sizeXY, 0.5*env_sizeXY, 0.5*env_sizeZ); //its size
      
  G4LogicalVolume* logicEnv =                         
    new G4LogicalVolume(solidEnv,            //its solid
//                        env_mat,             //its material
                       vacuum,
                        "Envelope");         //its name
               
  new G4PVPlacement(0,                       //no rotation
                    G4ThreeVector(),         //at (0,0,0)
                    logicEnv,                //its logical volume
                    "Envelope",              //its name
                    logicWorld,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking
 
     
  // Shape 2
  //
  //G4Material* shape2_mat = nist->FindOrBuildMaterial(G4_BONE_COMPACT_ICRU);

  G4Material* shape2_mat = nist->FindOrBuildMaterial("G4_BONE_COMPACT_ICRU");
  G4ThreeVector pos2 = G4ThreeVector(0., 0., 0.*cm);
  G4ThreeVector pos3 = G4ThreeVector(-8.*cm,0.,2.*cm);
	
  G4ThreeVector pos4 = G4ThreeVector(8.*cm,0.,1.*cm);
  G4double shape2_size = 10.*cm;
  G4double shape2_depth = 2.0*cm;

  // Shape 2
  G4Box* solidShape2 =    
    new G4Box("Shape2",                    //its name
        shape2_size, shape2_size, shape2_depth); //its size
      
  G4LogicalVolume* logicShape2 =                         
    new G4LogicalVolume(solidShape2,            //its solid
                        shape2_mat,             //its material
//                        vacuum,
                        "Shape2");         //its name
               
  new G4PVPlacement(0,                       //no rotation
                    pos2,         //at (0,0,0)
                    logicShape2,                //its logical volume
                    "Shape2",              //its name
                    logicEnv,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking

  fScoringVolume = logicShape2;

  return physWorld;
}
